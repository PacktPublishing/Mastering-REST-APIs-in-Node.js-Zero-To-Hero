const employeeResolvers = require('./employee');
const departmentResolvers = require('./department');
module.exports = [employeeResolvers, departmentResolvers];