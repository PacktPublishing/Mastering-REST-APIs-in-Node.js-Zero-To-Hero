const APIServerPort = 3000;

const database = {
  host: 'localhost',
  port: 27017
};

module.exports = {
  database,
  APIServerPort
};