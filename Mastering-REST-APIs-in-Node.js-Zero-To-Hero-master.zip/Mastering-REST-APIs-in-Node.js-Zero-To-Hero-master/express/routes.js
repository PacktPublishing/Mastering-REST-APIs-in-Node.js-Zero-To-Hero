const employees = require('./employeeController');
const departments = require('./departmentController');
module.exports = {
  employees,
  departments
};